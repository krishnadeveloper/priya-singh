var gulp = require('gulp'),
    sass = require('gulp-sass'),
    contact = require('gulp-concat'),
    uglify = require('gulp-uglify');


// Hpmepage Task    
gulp.task('homepage',function(){
    return gulp.src('src/sass/home/*.scss')
        .pipe(sass())
        .pipe(gulp.dest('src/assets/css/home/'))
});

// Comman Task
gulp.task('comman',function(){
    return gulp.src('src/sass/comman/*.scss')
    .pipe(sass())
    .pipe(gulp.dest('src/assets/css/comman/'));
})


// Login Task
gulp.task('login',function(){
    return gulp.src('src/sass/login/*.scss')
    .pipe(sass())
    .pipe(gulp.dest('src/assets/css/login/'));
});

// Twitter screen for any twitter handle
gulp.task('twitter',function(){
    return gulp.src('src/sass/twitter/*.scss')
        .pipe(sass())
        .pipe(gulp.dest('src/assets/css/twitter'));
})

// Twitter  card design
gulp.task('twittercard',function(){
    return gulp.src('src/sass/twitter/card/*.scss')
        .pipe(sass())
        .pipe(gulp.dest('src/assets/css/twitter/card/'));
})

// Watch Task
gulp.task('watch', function() {
    gulp.watch('src/sass/home/*.scss', gulp.series('homepage'));
    gulp.watch('src/sass/comman/*.scss', gulp.series('comman'));
    gulp.watch('src/sass/login/*.scss', gulp.series('login'));
    gulp.watch('src/sass/twitter/*.scss', gulp.series('twitter'));
    gulp.watch('src/sass/twitter/card/*.scss', gulp.series('twittercard'));
});


// Execute all tasks, which are passed under glup.parallel
//gulp.task('default', gulp.parallel('homepage','comman','login','watch'));
