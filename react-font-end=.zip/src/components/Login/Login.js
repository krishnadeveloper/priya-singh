import React, { Component } from 'react';
import '../../assets/css/login/login.css';


class Login extends Component {
    render() {
        return (
            <div className="login-container">
                <div className='login-section'>
                    <div className="heading">Login</div>
                    <div className="login-input-section">
                        <div className="input-control">
                            <label>Username</label>
                            <input className="form-input" value="" />
                        </div>

                        <div className="input-control">
                            <label>Username</label>
                            <input className="form-input" value="" />
                        </div>

                        <div className="input-control">
                            <button className="btn"> Login</button>
                        </div>
                    </div>
                </div>
                
            </div>
        );
    }
}

export default Login;