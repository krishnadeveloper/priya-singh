import React from 'react';
import dateformat from "dateformat";
import '../../assets/css/twitter/card/twittercard.css';

const TwitterCard = (props) => (
    <React.Fragment>
        <div className="tw-card">
            <div className="tw-header">
                <div className="tw-img">
                    <img src={props.detail.profile} alt={props.detail.id} />
                </div>
                <div className="tw-heading">
                    <span className="tw-name">{props.detail.name}</span>
                    <span className="tw-handle">@{props.detail.handle}</span>
                    <span className="tw-date"> at {dateformat(props.detail.created,'dd mmm, yyyy')}</span>
                </div>
            </div>
            <div className="tw-content">
                {props.detail.text}
            </div>
            <div className="tw-footer">
                <div className="retw-count">
                    Re-Tweets ({props.detail.reTweetCount}) 
                </div>
                <div className="fav-count">
                    Favorite ({props.detail.favCount})
                </div>
            </div>
        </div>
    </React.Fragment>
);

export default TwitterCard;