import React from 'react';
import searchClass from "../../lib/search.class";

const MakeSearch = (text,searchOn='content') =>{
    
    if (searchOn==='card') {
        searchClass.onCard(text);
    } else {
        searchClass.onContentOnly(text);
        
    }
        
}

const Search = (props) => {
    return(
        <input
            name={props.name}
            onChange={MakeSearch(props.defaultValue,props.searchOn)}
            defaultValue={props.defaultValue}
            {...props}
            className={props.className}

        />
        
    )
}

export default Search;