import React from 'react';


const SearchOption = (props) => {
    return (
        <React.Fragment>
            <select
            name={props.name}
            onChange={props.onChange}
            className={props.className}
            >
            <option value="content">Search on content</option>
            <option value="card">Search on card</option>
            
            </select>
        </React.Fragment>
    );
};

export default SearchOption;