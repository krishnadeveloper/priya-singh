import React, { Component } from 'react';
import TwitterRequest from "../../request/twitter/TwitterRequest";
import TwitterCard from './TwitterCard';
import Search from './Search';
import SearchOption from './SearchOption';
import "../../assets/css/twitter/twitter.css";
import Loader from "react-loader-spinner";

class Twitter extends Component {
    
    constructor()
    {
        super();
        this.state = {
            tweets :[],
            loading:true,
            searchText:'',
            searchOn:'content',
            twitterHandle:'',
            twitterError:'No tweet found'

        }
        this.setSearchText = this.setSearchText.bind(this);
        this.setOption     = this.setOption.bind(this);
        this.sendRequest   = this.sendRequest.bind(this);
    }

    setSearchText = (event)=>{
        this.setState({searchText:event.target.value})
    }

    setOption = (event)=>{
        this.setState({searchOn:event.target.value})
    }

    setTwitterHandle = (event) =>{
        this.setState({
            tweets:[],
            twitterHandle:event.target.value,
            loading:true
        });
        this.forceUpdate();
    }

    componentWillMount()
    {
        this.setState({
            loading:true
        })
        this.sendRequest();
    }


    sendRequest = () =>{

        TwitterRequest.fetchAllTweets(this.state.twitterHandle)
        .then((res)=>{
            if(res.data.status===true)
            {
                res.data.data.map(tweet=>{
                   return this.state.tweets.push(TwitterRequest.formateTweet(tweet.id,tweet.text,tweet.user.profile_image_url,tweet.user.name,tweet.user.screen_name,tweet.created_at,tweet.favorite_count,tweet.retweet_count));
                });
                this.setState({
                    loading:false
                })

                this.forceUpdate();
            }
            else{
                console.log(res.data.error)
                var err = '';
                if(res.data.error.length>0)
                {

                    res.data.error.map(error=>{
                        console.log(error.message);
                        err = err+error.message
                    })
                }
                else
                {
                    err = 'No tweets are found.'
                }

                this.setState({
                    twitterError:err,
                    loading:false
                })
            }
        })
        .catch((err)=>{
            console.log(err);
        });
    }
    
    render() {
        return (
            
            <div className="twitter">
                <div className="handle-input">
                    <span className="twitter-handle-tag">@</span><input onKeyUp={this.setTwitterHandle} onBlur={this.sendRequest} defaultValue={this.state.twitterHandle} placeholder="Enter twitter username" />
                </div>
                <SearchOption 
                    name="searchoptions"
                    onChange={this.setOption}
                    className="search-option"

                />
                <Search 
                    name="searchtweet" 
                    defaultValue={this.state.searchText} 
                    onChange={this.setSearchText} 
                    searchOn={this.state.searchOn}
                    className="search-input"
                    placeholder="Enter text to search"
                />
                
                {this.state.loading?
                    <div className="twitter-loader">
                        <Loader type="Puff" color="#1da1f2" height={80} width={80}  />
                    </div>
                    :
                    this.state.tweets.length>0
                        ?
                        this.state.tweets.map(tweet=>{
                            return <TwitterCard key={tweet.id} detail={tweet}/>
                        })
                        :
                        <div className="no-tweeet-found">
                            {this.state.twitterError}
                        </div>
                }
            </div>
        );
    }
}

export default Twitter;