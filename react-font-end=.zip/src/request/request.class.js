/**
 * Author : Krishna Kumar
 * Description : This class contain all api enpoints. 
 */
class Endpoint
{
    constructor()
    {
        this.apiHost    = "localhost";
        this.protocol   = 'http';
        this.port       = "8080";
    }

    mainUrl() {
        var url = this.protocol+'://';
        url = url+this.apiHost;
        url = url+(this.port?':'+this.port+'/':'/');
        return url;
    }

    allTweetsEndpoint(screen_name='')
    {
        return this.mainUrl()+'tweets'+(screen_name!==''?'/'+screen_name:'');
    }
}

export default Endpoint;