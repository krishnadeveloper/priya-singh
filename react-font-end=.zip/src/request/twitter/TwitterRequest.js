import ApiEndpoint from '../request.class'; // Reference of enpoints class
import axios from "axios"; 
/**
 * Author : Krishna Kumar
 * Description : All server request will be handle from @Twitter class
 */

class Twitter extends ApiEndpoint
{
    fetchAllTweets(screen_name='')
    {
        console.log(screen_name);
        return axios.get(this.allTweetsEndpoint(screen_name));  
    }

    formateTweet(id,text,profile,name,handle,created,favCount,reTweetCount){
        return {id,text,profile,name,handle,created,favCount,reTweetCount};
    }
}


export default new Twitter();