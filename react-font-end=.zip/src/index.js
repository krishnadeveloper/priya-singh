import React from 'react';
import ReactDOM from 'react-dom';
import '../src/assets/css/comman/comman.css';
//import App from '../src/components/Login';
import App from '../src/components/Twitter';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
