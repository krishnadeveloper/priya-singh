const express = require('express');
const router = express.Router();
const Twitter = require('twitter');
const TwiiterConfig = require('../config/twitter');

const tClient = new Twitter(TwiiterConfig);


router.get('/tweets/:screen_name?',(req,res,next)=>{
    var screenname = req.params.screen_name;
    var params = {screen_name: screenname?screenname:'algoscale'};
    const allTw = {};
    tClient.get('statuses/user_timeline', params, function(error, tweets, response) {
    if (!error) {
        allTw.status = true;
        allTw.data = tweets;
        allTw.error = null;

    }
    else{
        
        allTw.status = false;
        allTw.data = null;
        allTw.error = error;
    }

    res.json(allTw);

    });
    
})

module.exports = router;