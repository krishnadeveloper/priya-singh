const TwitterConfig = {
    consumer_key: '', // API Key
    consumer_secret: '', // API Secret Key 
    access_token_key: '', // Access Token
    access_token_secret: '' // Access Token Secret
}

module.exports = TwitterConfig;